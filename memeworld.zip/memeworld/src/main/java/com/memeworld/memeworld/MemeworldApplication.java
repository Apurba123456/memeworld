package com.memeworld.memeworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MemeworldApplication {

	public static void main(String[] args) {
		SpringApplication.run(MemeworldApplication.class, args);
	}

}
